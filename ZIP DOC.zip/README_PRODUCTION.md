
Production Deployment Guide
===========================

This package contains a production-ready scaffold for the School Management System (Flask).
It includes Dockerfile, docker-compose.yml (Flask + Postgres + Nginx), nginx config, and example systemd service.

**Important references**
- Safaricom Daraja (M-Pesa) docs (for payments): https://developer.safaricom.co.ke/Documentation. citeturn0search0turn0search5
- How to serve Flask with Gunicorn & Nginx (DigitalOcean): citeturn0search1turn0search15
- Certbot / Let's Encrypt instructions for Nginx: citeturn0search6turn0search22
- Dockerize Flask + Postgres guide (example): citeturn0search8turn0search23

Steps to deploy (high-level)
1. Prepare a server or cloud hosting account (DigitalOcean, AWS EC2, Hetzner). Create DNS A record for your domain pointing to the server IP.
2. Copy files to server or push to a Git repo and pull on server.
3. Create a `.env` file from `.env.sample` and set secure values.
4. (Docker) Install Docker and Docker Compose on server. Then run:
   - `docker-compose up -d --build`
5. (Non-Docker) Create Python venv, install requirements, configure Gunicorn + Nginx following DigitalOcean guides. See references above.
6. Obtain SSL cert with Certbot:
   - `sudo certbot --nginx -d yourdomain.com`
   - Certbot will edit nginx config and enable HTTPS. See certbot docs. citeturn0search6turn0search22
7. Configure M-Pesa (Daraja) sandbox and production credentials. Use the Daraja docs to register for keys and test STK Push or B2C/B2B as needed. citeturn0search0turn0search5
8. Set up backups: Postgres dump (cron) or managed DB backups (RDS, DigitalOcean Managed DB).
9. Monitoring & logging: use Sentry for error tracking, and Prometheus/Grafana or cloud monitoring for metrics.
10. Setup CI/CD (GitHub Actions / GitLab CI) to build and push images or deploy via SSH.

Security checklist
- Use strong SECRET_KEY and never commit `.env` to git.
- Use database users with least privilege.
- Serve app behind Nginx and enable HTTPS (Let's Encrypt).
- Hash passwords (demo currently stores plain text; in production use proper password hashing).
- Enable regular automated backups and test restores.

Notes about this package
- The demo app uses SQLite and stores plain-text passwords for simplicity. Replace with PostgreSQL and proper password hashing in production.
- The docker-compose.yml mounts a `certs` volume for Let's Encrypt; in production you must ensure certbot is run to populate that volume or use a reverse proxy service that handles TLS.

If you want, I can now:
- (A) Generate the production zip (I already did) and provide a download link.
- (B) Replace plain-text password logic with Flask-Security/Flask-Login + hashed passwords and add migrations (Flask-Migrate).
- (C) Create GitHub Actions workflow for CI/CD (build/push Docker image).
- (D) Prepare step-by-step DigitalOcean droplet setup script.

Tell me which of B/C/D you'd like me to add now and I'll produce it immediately.



## Deploy to Render (quick)
1. Create a GitHub repo and push this project to the `main` branch.
2. Go to https://render.com and sign in (or sign up with GitHub).
3. In Render dashboard, click **New +** → **Web Service** → Connect a repo.
4. Choose your `christian-school-system` repo and select branch `main`.
5. Environment: **Docker**. Service name: `christian-school-system`.
6. Add Environment Variables in Render dashboard (Settings → Environment → Environment Variables):
   - SECRET_KEY (use a long random value)
   - POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_DB (or use Render's managed Postgres)
7. Click **Create Web Service**. Render will build and deploy your app and give you a URL like:
   `https://christian-school-system.onrender.com`
8. (Optional) Add a custom domain in Render and follow DNS instructions to point your domain.

### Deploy button (manual)
Render does not officially support a single-button deploy like Heroku, but using the `render.yaml` in the repo allows Render to import and auto-create services. When you import the repo in Render, choose "Import from render.yaml".
