
School Management Demo (Primary + Nursery)
=========================================

Quick start (local):
1. Create a Python 3 virtualenv and activate it.
2. Install dependencies:
   pip install -r requirements.txt
3. Run the app:
   python app.py
4. Open browser: http://127.0.0.1:5000

Login credentials:
- Username: admin
- Password: 12345
- Owner shown in UI: CHRISTIAN PETER MTIRO

This demo is intentionally simple and uses SQLite. For production, migrate to PostgreSQL and secure secret keys.

Files included:
- app.py (Flask app)
- requirements.txt
- templates/ (HTML)
- static/ (CSS)
