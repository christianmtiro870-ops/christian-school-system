
# christian-school-system

This repository is ready to be imported to Render using `render.yaml`. Steps:

1. Create a GitHub repository and push all files.
2. On Render, choose "Import from GitHub" and select this repository.
3. If Render asks, allow it to import services from `render.yaml`.

If you need, follow the 'Production Deployment Guide' in README_PRODUCTION.md.
