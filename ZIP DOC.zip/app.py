
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import os
from datetime import date

app = Flask(__name__)
app.secret_key = 'change-this-secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///school_demo.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50), nullable=False)
    full_name = db.Column(db.String(200), nullable=True)

class Guardian(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200))
    phone = db.Column(db.String(50))
    email = db.Column(db.String(200))
    relation = db.Column(db.String(50))

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admission_no = db.Column(db.String(50), unique=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    dob = db.Column(db.String(20))
    gender = db.Column(db.String(10))
    guardian_id = db.Column(db.Integer, db.ForeignKey('guardian.id'))
    level = db.Column(db.String(50))  # Nursery or Primary

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    date = db.Column(db.String(20))
    status = db.Column(db.String(20))  # present/absent/late

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_no = db.Column(db.String(50), unique=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    amount = db.Column(db.Float)
    status = db.Column(db.String(30))  # pending/paid

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'))
    amount = db.Column(db.Float)
    method = db.Column(db.String(50))

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    subject = db.Column(db.String(100))
    score = db.Column(db.Float)
    term = db.Column(db.String(50))
    year = db.Column(db.Integer)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes

@app.route('/')
def index():
    # Public homepage for visitors; shows brief info and login link
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('public_home.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    total_students = Student.query.count()
    today = date.today().isoformat()
    present_today = Attendance.query.filter_by(date=today, status='present').count()
    unpaid = Invoice.query.filter_by(status='pending').count()
    return render_template('dashboard.html', total_students=total_students, present_today=present_today, unpaid=unpaid)

# Students
@app.route('/students')
@login_required
def students():
    students = Student.query.all()
    guardians = {g.id: g for g in Guardian.query.all()}
    return render_template('students.html', students=students, guardians=guardians)

@app.route('/students/add', methods=['GET','POST'])
@login_required
def add_student():
    if request.method=='POST':
        adm = request.form['admission_no']
        fn = request.form['first_name']
        ln = request.form['last_name']
        dob = request.form['dob']
        gender = request.form['gender']
        guardian_name = request.form['guardian_name']
        guardian_phone = request.form['guardian_phone']
        level = request.form['level']
        # create guardian
        g = Guardian(name=guardian_name, phone=guardian_phone)
        db.session.add(g)
        db.session.commit()
        s = Student(admission_no=adm, first_name=fn, last_name=ln, dob=dob, gender=gender, guardian_id=g.id, level=level)
        db.session.add(s)
        db.session.commit()
        flash('Student added', 'success')
        return redirect(url_for('students'))
    return render_template('add_student.html')

# Attendance
@app.route('/attendance', methods=['GET','POST'])
@login_required
def attendance():
    students = Student.query.all()
    today = date.today().isoformat()
    if request.method=='POST':
        for s in students:
            status = request.form.get(f'status_{s.id}', 'absent')
            # upsert
            existing = Attendance.query.filter_by(student_id=s.id, date=today).first()
            if existing:
                existing.status = status
            else:
                a = Attendance(student_id=s.id, date=today, status=status)
                db.session.add(a)
        db.session.commit()
        flash('Attendance saved for ' + today, 'success')
        return redirect(url_for('attendance'))
    records = {a.student_id: a for a in Attendance.query.filter_by(date=today).all()}
    return render_template('attendance.html', students=students, records=records, today=today)

# Invoices and payments
@app.route('/invoices')
@login_required
def invoices():
    invoices = Invoice.query.all()
    students = {s.id: s for s in Student.query.all()}
    return render_template('invoices.html', invoices=invoices, students=students)

@app.route('/invoices/add', methods=['GET','POST'])
@login_required
def add_invoice():
    if request.method=='POST':
        invoice_no = request.form['invoice_no']
        student_id = int(request.form['student_id'])
        amount = float(request.form['amount'])
        inv = Invoice(invoice_no=invoice_no, student_id=student_id, amount=amount, status='pending')
        db.session.add(inv)
        db.session.commit()
        flash('Invoice created', 'success')
        return redirect(url_for('invoices'))
    students = Student.query.all()
    return render_template('add_invoice.html', students=students)

@app.route('/payments/pay/<int:invoice_id>', methods=['POST'])
@login_required
def pay_invoice(invoice_id):
    inv = Invoice.query.get(invoice_id)
    if not inv:
        flash('Invoice not found', 'danger')
        return redirect(url_for('invoices'))
    amount = float(request.form['amount'])
    method = request.form['method']
    p = Payment(invoice_id=inv.id, amount=amount, method=method)
    db.session.add(p)
    # update invoice status if fully paid
    total_paid = sum([pay.amount for pay in Payment.query.filter_by(invoice_id=inv.id).all()]) + amount
    if total_paid >= inv.amount:
        inv.status = 'paid'
    db.session.commit()
    flash('Payment recorded', 'success')
    return redirect(url_for('invoices'))

# Grades
@app.route('/grades', methods=['GET','POST'])
@login_required
def grades():
    students = Student.query.all()
    if request.method=='POST':
        for s in students:
            subj = request.form.get(f'subject_{s.id}')
            score = request.form.get(f'score_{s.id}')
            if subj and score:
                g = Grade(student_id=s.id, subject=subj, score=float(score), term='Term 1', year=2025)
                db.session.add(g)
        db.session.commit()
        flash('Grades saved', 'success')
        return redirect(url_for('grades'))
    grades = Grade.query.all()
    return render_template('grades.html', students=students, grades=grades)

# Simple reports
@app.route('/reports/students')
@login_required
def report_students():
    students = Student.query.all()
    return render_template('report_students.html', students=students)

# Static files serving (for download)
@app.route('/download/<path:filename>')
def download_file(filename):
    return send_from_directory(os.path.abspath('.'), filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
